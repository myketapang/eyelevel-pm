import { useState } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { apiRequest, queryClient } from "@/lib/queryClient";
import { Task, InsertTask, Project } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertTaskSchema } from "@shared/schema";
import { Loader2, Plus, GripVertical } from "lucide-react";
import { Badge } from "@/components/ui/badge";

const COLUMNS = [
  { id: 'todo', title: 'To Do', color: 'bg-slate-100 dark:bg-slate-900' },
  { id: 'in_progress', title: 'In Progress', color: 'bg-blue-50 dark:bg-blue-950/20' },
  { id: 'review', title: 'Review', color: 'bg-amber-50 dark:bg-amber-950/20' },
  { id: 'done', title: 'Done', color: 'bg-green-50 dark:bg-green-950/20' }
];

export default function Tasks() {
  const [open, setOpen] = useState(false);
  const { data: tasks, isLoading: tasksLoading } = useQuery<Task[]>({ 
    queryKey: ["/api/tasks"] 
  });
  const { data: projects } = useQuery<Project[]>({ 
    queryKey: ["/api/projects"] 
  });

  const form = useForm<InsertTask>({
    resolver: zodResolver(insertTaskSchema),
    defaultValues: {
      title: "",
      description: "",
      status: "todo",
      priority: "medium",
      projectId: undefined
    }
  });

  const createMutation = useMutation({
    mutationFn: async (data: InsertTask) => {
      // Coerce projectId to number if string
      if (typeof data.projectId === 'string') {
        data.projectId = parseInt(data.projectId);
      }
      const res = await apiRequest("POST", "/api/tasks", data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
      setOpen(false);
      form.reset();
    }
  });
  
  const updateStatusMutation = useMutation({
    mutationFn: async ({ id, status }: { id: number, status: string }) => {
      const res = await apiRequest("PUT", `/api/tasks/${id}`, { status });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/tasks"] });
    }
  });

  if (tasksLoading) return <div className="flex justify-center p-8"><Loader2 className="h-8 w-8 animate-spin" /></div>;

  return (
    <div className="space-y-6 h-full">
      <div className="flex justify-between items-center">
        <h2 className="text-3xl font-bold tracking-tight">Tasks Board</h2>
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button><Plus className="mr-2 h-4 w-4" /> New Task</Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>Create New Task</DialogTitle>
            </DialogHeader>
            <Form {...form}>
              <form onSubmit={form.handleSubmit((data) => createMutation.mutate(data))} className="space-y-4">
                <FormField
                  control={form.control}
                  name="title"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Title</FormLabel>
                      <FormControl>
                        <Input placeholder="Task Title" {...field} />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="projectId"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Project</FormLabel>
                      <Select onValueChange={(val) => field.onChange(parseInt(val))} defaultValue={field.value?.toString()}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select Project" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          {projects?.map(p => (
                            <SelectItem key={p.id} value={p.id.toString()}>{p.name}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <FormField
                  control={form.control}
                  name="priority"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Priority</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value || "medium"}>
                         <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Priority" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="low">Low</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                <Button type="submit" disabled={createMutation.isPending}>
                  {createMutation.isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
                  Create
                </Button>
              </form>
            </Form>
          </DialogContent>
        </Dialog>
      </div>

      <div className="flex h-[calc(100vh-200px)] gap-4 overflow-x-auto pb-4">
        {COLUMNS.map(column => (
          <div key={column.id} className={`flex-1 min-w-[280px] rounded-lg p-4 ${column.color} flex flex-col gap-4`}>
            <h3 className="font-semibold text-sm uppercase tracking-wider text-muted-foreground mb-2 flex justify-between">
              {column.title}
              <span className="bg-background/50 px-2 py-0.5 rounded-full text-xs">
                {tasks?.filter(t => t.status === column.id).length}
              </span>
            </h3>
            <div className="space-y-3 overflow-y-auto pr-2">
              {tasks?.filter(t => t.status === column.id).map(task => (
                <Card key={task.id} className="cursor-grab active:cursor-grabbing hover-elevate group">
                  <CardContent className="p-3 space-y-2">
                    <div className="flex justify-between items-start gap-2">
                      <span className="font-medium text-sm leading-tight">{task.title}</span>
                      <GripVertical className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    {task.description && (
                       <p className="text-xs text-muted-foreground line-clamp-2">{task.description}</p>
                    )}
                    <div className="flex justify-between items-center mt-2">
                      <Badge variant="outline" className={`text-[10px] py-0 h-5 
                        ${task.priority === 'high' ? 'border-red-200 text-red-700 bg-red-50' : 
                          task.priority === 'medium' ? 'border-amber-200 text-amber-700 bg-amber-50' : 
                          'border-slate-200 text-slate-700'}`}>
                        {task.priority}
                      </Badge>
                      
                      <div className="flex gap-1">
                        {/* Simple controls to move tasks since DnD is complex to implement fully in one go */}
                        {column.id !== 'todo' && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6" 
                            onClick={() => updateStatusMutation.mutate({ id: task.id, status: getPrevStatus(column.id) })}
                          >
                            ←
                          </Button>
                        )}
                        {column.id !== 'done' && (
                          <Button 
                            variant="ghost" 
                            size="icon" 
                            className="h-6 w-6"
                            onClick={() => updateStatusMutation.mutate({ id: task.id, status: getNextStatus(column.id) })}
                          >
                            →
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function getNextStatus(current: string) {
  const map: Record<string, string> = { 'todo': 'in_progress', 'in_progress': 'review', 'review': 'done' };
  return map[current];
}

function getPrevStatus(current: string) {
  const map: Record<string, string> = { 'done': 'review', 'review': 'in_progress', 'in_progress': 'todo' };
  return map[current];
}
