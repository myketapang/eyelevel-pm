import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

export default function Team() {
  const members = [
    { name: "Alice Johnson", role: "Project Manager", initials: "AJ" },
    { name: "Bob Smith", role: "Developer", initials: "BS" },
    { name: "Charlie Brown", role: "Designer", initials: "CB" },
    { name: "Diana Prince", role: "Product Owner", initials: "DP" },
  ];

  return (
    <div className="space-y-6">
      <h2 className="text-3xl font-bold tracking-tight">Team Members</h2>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {members.map((member) => (
          <Card key={member.name} className="hover-elevate">
            <CardHeader className="flex flex-row items-center space-x-4 pb-2">
              <Avatar className="h-12 w-12">
                <AvatarImage src={`https://api.dicebear.com/7.x/initials/svg?seed=${member.initials}`} />
                <AvatarFallback>{member.initials}</AvatarFallback>
              </Avatar>
              <div>
                <CardTitle className="text-base">{member.name}</CardTitle>
                <div className="text-sm text-muted-foreground">{member.role}</div>
              </div>
            </CardHeader>
            <CardContent>
              <div className="text-sm text-muted-foreground mt-2">
                Active on 3 projects
              </div>
            </CardContent>
          </Card>
        ))}
      </div>
    </div>
  );
}
